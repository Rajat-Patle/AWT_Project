const data = null;

const xhr = new XMLHttpRequest();
xhr.withCredentials = true;

const getWeather = (city) => {
	cityname.innerHTML = city;
	xhr.addEventListener('readystatechange', function () {
		if (this.readyState === this.DONE) {
			console.log(this.responseText);

			// Parse the response text to JSON
			const response = JSON.parse(this.responseText);

			// Check if the response has the expected structure
			if (response && response.weather && response.main && response.wind) {
				// Convert temperatures from Kelvin to Celsius
				const tempCelsius = (response.main.temp - 273.15).toFixed(2);
				const feelsLikeCelsius = (response.main.feels_like - 273.15).toFixed(2);
				const tempMinCelsius = (response.main.temp_min - 273.15).toFixed(2);
				const tempMaxCelsius = (response.main.temp_max - 273.15).toFixed(2);

				// Extract and display the weather information
				description.innerHTML = response.weather[0].description;
				temp.innerHTML = tempCelsius + ' °C';
				temp2.innerHTML = tempCelsius + ' °C';
				feels_like.innerHTML = feelsLikeCelsius + ' °C';
				temp_min.innerHTML = tempMinCelsius + ' °C';
				temp_max.innerHTML = tempMaxCelsius + ' °C';
				pressure.innerHTML = response.main.pressure + ' hPa';
				humidity.innerHTML = response.main.humidity + ' %';
				humidity2.innerHTML = response.main.humidity;
				
				if (response.main.sea_level) {
					sea_level.innerHTML = response.main.sea_level + ' hPa';
				}
				if (response.main.grnd_level) {
					grnd_level.innerHTML = response.main.grnd_level + ' hPa';
				}
				visibility.innerHTML = response.visibility + ' m';
				//visibility2.innerHTML = response.visibility + ' m';
				speed2.innerHTML =speed.innerHTML = response.wind.speed + ' m/s';
				
				//  speed + ' m/s';
				deg.innerHTML = response.wind.deg + ' °';
			} else {
				console.error("Unexpected response structure:", response);
			}
		}
	});

	xhr.open('GET', 'https://weather-api138.p.rapidapi.com/weather?city_name=' + city);
	xhr.setRequestHeader('x-rapidapi-key', '6727edf07emshbe514af1ea33100p1c5893jsn09293d524416');
	xhr.setRequestHeader('x-rapidapi-host', 'weather-api138.p.rapidapi.com');

	xhr.send(data);
}

submit.addEventListener("click", (e) => {
	e.preventDefault();
	getWeather(city.value);
})

getWeather("Nagpur");


