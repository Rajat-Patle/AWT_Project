const data2 = null;

const xhr2 = new XMLHttpRequest();
xhr2.withCredentials = true;

const updateWeatherRow = (city) => {
    xhr2.addEventListener('readystatechange', function () {
        if (this.readyState === this.DONE) {
            console.log(this.responseText);

            const response = JSON.parse(this.responseText);

            if (response && response.weather && response.main && response.wind) {
                const tempCelsius = (response.main.temp - 273.15).toFixed(2);
                const feelsLikeCelsius = (response.main.feels_like - 273.15).toFixed(2);
                const tempMinCelsius = (response.main.temp_min - 273.15).toFixed(2);
                const tempMaxCelsius = (response.main.temp_max - 273.15).toFixed(2);

                // Get the table by ID
                var table = document.getElementById("text-center"); // Update the ID

               

                // Assuming the row for Delhi is the first row in the tbody (index 1)
                var row = table.rows[1]; // Change index if the row is not the first one

                if (!row) {
                    console.error("Row not found!");
                    return;
                }

                // Update cells with weather data
                row.cells[0].innerHTML = city; // City
                row.cells[1].innerHTML = response.weather[0].description; // Description
                row.cells[2].innerHTML = tempCelsius + ' °C'; // Temperature
                row.cells[3].innerHTML = feelsLikeCelsius + ' °C'; // Feels Like
                row.cells[4].innerHTML = tempMinCelsius + ' °C'; // Min Temperature
                row.cells[5].innerHTML = tempMaxCelsius + ' °C'; // Max Temperature
                row.cells[6].innerHTML = response.main.pressure + ' hPa'; // Pressure
                row.cells[7].innerHTML = response.main.humidity + ' %'; // Humidity
                row.cells[8].innerHTML = response.wind.speed + ' m/s'; // Wind Speed
                row.cells[9].innerHTML = response.wind.deg + ' °'; // Wind Direction
            } else {
                console.error("Unexpected response structure:", response);
            }
        }
    });

    xhr2.open('GET', 'https://weather-api138.p.rapidapi.com/weather?city_name=' + city);
    xhr2.setRequestHeader('x-rapidapi-key', '6727edf07emshbe514af1ea33100p1c5893jsn09293d524416');
    xhr2.setRequestHeader('x-rapidapi-host', 'weather-api138.p.rapidapi.com');
    xhr2.send(data2);
}

// Ensure this runs after the DOM has loaded

    updateWeatherRow("Pune");

