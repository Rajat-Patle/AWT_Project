const data = null;
const xhr = new XMLHttpRequest();
xhr.withCredentials = true;

// Get DOM elements individually
const description = document.querySelectorAll('[id^="description"]');
const temp = document.querySelectorAll('[id^="temp"]');
const feels_like = document.querySelectorAll('[id^="feels_like"]');
const temp_min = document.querySelectorAll('[id^="temp_min"]');
const temp_max = document.querySelectorAll('[id^="temp_max"]');
const pressure = document.querySelectorAll('[id^="pressure"]');
const humidity = document.querySelectorAll('[id^="humidity"]');
const sea_level = document.querySelectorAll('[id^="sea_level"]');
const grnd_level = document.querySelectorAll('[id^="grnd_level"]');
const visibility = document.querySelectorAll('[id^="visibility"]');
const speed = document.querySelectorAll('[id^="speed"]');
const deg = document.querySelectorAll('[id^="deg"]');

// The getWeather function (for the cards)
const getWeather = (city, i) => {
    xhr.addEventListener('readystatechange', function () {
        if (this.readyState === this.DONE) {
            console.log(this.responseText);

            // Parse the response text to JSON
            const response = JSON.parse(this.responseText);

            // Check if the response has the expected structure
            if (response && response.weather && response.main && response.wind) {
                // Convert temperatures from Kelvin to Celsius
                const tempCelsius = (response.main.temp - 273.15).toFixed(2);
                const feelsLikeCelsius = (response.main.feels_like - 273.15).toFixed(2);
                const tempMinCelsius = (response.main.temp_min - 273.15).toFixed(2);
                const tempMaxCelsius = (response.main.temp_max - 273.15).toFixed(2);

                // Extract and display the weather information for the cards
                if (i === 0) {
                    // Only update the card data for index 0 (default display or searched city)
                    description[0].innerHTML = response.weather.description;
                    temp[0].innerHTML = tempCelsius + ' °C';
                    feels_like[0].innerHTML = feelsLikeCelsius + ' °C';
                    temp_min[0].innerHTML = tempMinCelsius + ' °C';
                    temp_max[0].innerHTML = tempMaxCelsius + ' °C';
                    pressure[0].innerHTML = response.main.pressure + ' hPa';
                    humidity[0].innerHTML = response.main.humidity + ' %';
                    visibility[0].innerHTML = response.visibility + ' m';
                    speed[0].innerHTML = response.wind.speed + ' m/s';
                    deg[0].innerHTML = response.wind.deg + ' °';
                }
            } else {
                console.error("Unexpected response structure:", response);
            }
        }
    });

    xhr.open('GET', 'https://weather-api138.p.rapidapi.com/weather?city_name=' + city);
    xhr.setRequestHeader('x-rapidapi-key', '6727edf07emshbe514af1ea33100p1c5893jsn09293d524416');
    xhr.setRequestHeader('x-rapidapi-host', 'weather-api138.p.rapidapi.com');

    xhr.send(data);
}

// Event listener for the search button (for cards)
submit.addEventListener("click", (e) => {
    e.preventDefault();

    const cityName = city.value; // Get the input city value
    cityname.innerHTML = cityName; // Update displayed city name

    getWeather(cityName, 0); // Update card with search result, only at index 0 (card display)
});

// Function to get weather for the static table (common cities)
const getWeatherForTable = (city, i) => {
		xhr.addEventListener('readystatechange', function () {
			if (this.readyState === this.DONE) {
				console.log(this.responseText);
	
				const response = JSON.parse(this.responseText);
	
				if (response && response.weather && response.main && response.wind) {
					const tempCelsius = (response.main.temp - 273.15).toFixed(2);
					const feelsLikeCelsius = (response.main.feels_like - 273.15).toFixed(2);
					const tempMinCelsius = (response.main.temp_min - 273.15).toFixed(2);
					const tempMaxCelsius = (response.main.temp_max - 273.15).toFixed(2);
	
					// Target specific row and cells in the existing table by their index
					var table = document.getElementById("text-center");
	
					// Assume i corresponds to the row index, adjust as needed
					var row = table.rows[i];
	
					// Update the content of the existing cells
					row.cells[1].innerHTML = response.weather[0].description;
					row.cells[2].innerHTML = tempCelsius + ' °C';
					row.cells[3].innerHTML = feelsLikeCelsius + ' °C';
					row.cells[4].innerHTML = tempMinCelsius + ' °C';
					row.cells[5].innerHTML = tempMaxCelsius + ' °C';
					row.cells[6].innerHTML = response.main.pressure + ' hPa';
					row.cells[7].innerHTML = response.main.humidity + ' %';
					row.cells[8].innerHTML = response.wind.speed + ' m/s';
					row.cells[9].innerHTML = response.wind.deg + ' °';
				} else {
					console.error("Unexpected response structure:", response);
				}
			}
		});
	
		xhr.open('GET', 'https://weather-api138.p.rapidapi.com/weather?city_name=' + city);
		xhr.setRequestHeader('x-rapidapi-key', '6727edf07emshbe514af1ea33100p1c5893jsn09293d524416');
		xhr.setRequestHeader('x-rapidapi-host', 'weather-api138.p.rapidapi.com');
		xhr.send(data);
	}
	


// Initial load for static cities (common cities in the table)
getWeather("Nagpur", 0); // Default card display (Nagpur)
getWeatherForTable("Delhi", 1);
getWeatherForTable("Mumbai", 2);
getWeatherForTable("Nagpur", 3); // This is for the Nagpur row in the table
getWeatherForTable("Pune", 4);
