document.addEventListener("DOMContentLoaded", function () {
    const socket = io("http://127.0.0.1:5000");
    let digitElements = document.querySelectorAll(".digit");
    let statusElement = document.getElementById("status");

    // Get elements safely
    let responseTimeEl = document.getElementById("response-time");
    let dbLoadEl = document.getElementById("db-load");

    if (!responseTimeEl || !dbLoadEl) {
        console.error("System status elements not found!");
        return; // Stop execution to prevent further errors
    }

    // Track Performance Metrics
    let lastUpdateTime = performance.now();

    // WebSocket connection handling
    socket.on("connect", function () {
        statusElement.textContent = "Connected";
        statusElement.style.color = "green";
    });

    socket.on("update_display", function (digits) {
        if (!digits) return;

        requestAnimationFrame(() => {
            for (let i = 0; i < digits.length; i++) {
                digitElements[i].textContent = digits[i];
            }
        });

        updateChartThrottle(digits);
        updateSystemStatus();
    });

    // WebSocket Error Handling
    socket.on("disconnect", function () {
        statusElement.textContent = "Disconnected - Reconnecting...";
        statusElement.style.color = "red";
    });

    // Function to update system status metrics
    function updateSystemStatus() {
        let now = performance.now();
        let elapsedTime = (now - lastUpdateTime) / 1000; // Convert to seconds
        lastUpdateTime = now;

        // Update UI
        responseTimeEl.textContent = elapsedTime.toFixed(2) + " s";
        dbLoadEl.textContent = Math.floor(Math.random() * 100) + "%"; // Simulated database load
    }

    // Chart Setup
    const ctx = document.getElementById("chart").getContext("2d");
    let chart = new Chart(ctx, {
        type: "bar",
        data: {
            labels: ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"],
            datasets: [{ data: Array(10).fill(0), backgroundColor: "#4682B4" }]
        },
        options: { 
            animation: false, 
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: "Frequency of Digits (0-9) Appearing in the Transmitted Data",
                    position: "bottom",
                    font: { size: 20 }
                }
            }
        }
    });

    // Throttle function to limit chart updates
    let lastChartUpdate = 0;
    function updateChartThrottle(digits) {
        let now = performance.now();
        if (now - lastChartUpdate < 500) return;

        lastChartUpdate = now;
        setTimeout(() => updateChart(digits), 0);
    }

    function updateChart(digits) {
        let count = Array(10).fill(0);
        digits.split("").forEach(num => count[parseInt(num)]++);
        chart.data.datasets[0].data = count;
        chart.update();
    }
});
