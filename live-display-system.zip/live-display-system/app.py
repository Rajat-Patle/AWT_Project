import os
import random
import eventlet
import mysql.connector
from flask import Flask, jsonify
from flask_socketio import SocketIO
from flask_cors import CORS
from queue import Queue

eventlet.monkey_patch()

app = Flask(__name__)
CORS(app)
app.config['SECRET_KEY'] = os.getenv("FLASK_SECRET_KEY", "default_secret_key")
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="eventlet")

# Use a queue to minimize database writes
data_queue = Queue(maxsize=1)

# Database Connection Pooling
db_config = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "live_display_db",
    "pool_name": "mypool",
    "pool_size": 5
}

def get_db_connection():
    return mysql.connector.connect(**db_config)

# Function to Generate Random Digits
def generate_digits():
    return "".join(str(random.randint(0, 9)) for _ in range(12))

# Function to Save Data Efficiently
def save_to_db():
    while True:
        digits = data_queue.get()  # Get data from queue
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("INSERT INTO live_data (digits) VALUES (%s)", (digits,))
            conn.commit()
            cursor.close()
            conn.close()
        except Exception as e:
            print("Database Error:", e)

# Background Task: Efficient Data Generation & Transmission
def update_live_data():
    while True:
        digits = generate_digits()
        if data_queue.full():
            data_queue.get()  # Remove old data to maintain freshness
        data_queue.put(digits)
        socketio.emit("update_display", digits)  # Send data to frontend
        eventlet.sleep(0.2)  # Reduce latency (update every 0.3s)

# API Endpoint to Fetch Latest Data
@app.route("/latest", methods=["GET"])
def latest_data():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT digits, timestamp FROM live_data ORDER BY id DESC LIMIT 1")
    data = cursor.fetchone()
    cursor.close()
    conn.close()

    if data:
        return jsonify({"digits": data[0], "timestamp": str(data[1])})
    else:
        return jsonify({"error": "No data available"}), 404

# Start Background Processes
eventlet.spawn_n(update_live_data)  # Start optimized data generation
eventlet.spawn_n(save_to_db)  # Start efficient database writing

# SocketIO Connection Event
@socketio.on("connect")
def handle_connect():
    print("Client connected")

if __name__ == "__main__":
    socketio.run(app, host="0.0.0.0", port=5000, debug=True, allow_unsafe_werkzeug=True)